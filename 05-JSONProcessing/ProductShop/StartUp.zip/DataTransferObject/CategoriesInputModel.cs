﻿namespace ProductShop.DataTransferObject
{
    public class CategoriesInputModel
    {
        public string Name { get; set; }

    }
}
