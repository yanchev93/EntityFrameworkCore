﻿namespace Theatre.Data.Models
{
    public enum Genre
    {
        Drama,
        Comedy,
        Romance,
        Musical
    }
}
//•	Genre – enumeration of type Genre, with possible values (Drama, Comedy, Romance, Musical) (required)