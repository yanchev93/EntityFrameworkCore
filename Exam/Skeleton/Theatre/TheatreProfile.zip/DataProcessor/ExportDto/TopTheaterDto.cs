﻿namespace Theatre.DataProcessor.ExportDto
{
    public class TopTheaterDto
    {
        
    }
}

//{
//    "Name": "Capitol Theatre Building",
//    "Halls": 10,
//    "TotalIncome": 860.02,
//    "Tickets": [
//      {
//        "Price": 93.48,
//        "RowNumber": 3
//      },
//      {
//        "Price": 93.41,
//        "RowNumber": 1
//      },
//      {
//        "Price": 86.21,
//        "RowNumber": 5
//      },
//      {
//        "Price": 86.14,
//        "RowNumber": 5
//      },
//      {
//        "Price": 85.64,
//        "RowNumber": 4
//      },
//      {
//        "Price": 85.09,
//        "RowNumber": 1
//      },
//      {
//        "Price": 79.01,
//        "RowNumber": 3
//      },
//      {
//        "Price": 68.56,
//        "RowNumber": 1
//      },
//      {
//        "Price": 62.14,
//        "RowNumber": 3
//      },
//      {
//        "Price": 55.96,
//        "RowNumber": 1
//      },
//      {
//        "Price": 40.18,
//        "RowNumber": 5
//      },
//      {
//        "Price": 13.83,
//        "RowNumber": 3
//      },
//      {
//        "Price": 10.37,
//        "RowNumber": 3
//      }
//    ]
//  }
