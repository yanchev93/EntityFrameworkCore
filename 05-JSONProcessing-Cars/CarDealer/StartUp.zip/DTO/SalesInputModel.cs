﻿namespace CarDealer
{
    public class SalesInputModel
    {
        public int CarId { get; set; }

        public int CustomerId { get; set; }

        public int Discount { get; set; }
    }
}
