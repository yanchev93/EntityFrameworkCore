﻿namespace CarDealer.DTO
{
    public class SuppliersInputModel
    {
        public string Name { get; set; }

        public bool IsImported { get; set; }
    }
}
