﻿namespace MusicHub.Data.Models
{
    public enum Genre
    {
        Blues = 0,
        Rap = 1,
        PopMusic = 2,
        Rock = 3,
        Jazz = 4
    }
}

//Genre ¬– genre enumeration with possible values: "Blues, Rap, PopMusic, Rock, Jazz"(required)